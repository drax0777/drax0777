Welcome to hail Nukers Fam!

If u using this nuker so pls give me fucking credits..

fastest nuker ever!!

If u find some bugs so dm me for help! draxu#6999

HAiL NuKeR V2 SooN!!
